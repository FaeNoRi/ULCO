package lsg.buffs.talismans;

public class NoonGift extends Talisman {
	
	public NoonGift() {
		super("Noon Gift", 10.5f, 12, 14);
	}

}
