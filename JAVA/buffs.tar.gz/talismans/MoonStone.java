package lsg.buffs.talismans;

public class MoonStone extends Talisman {
	
	public MoonStone() {
		super("Moon Stone", 20f, 21, 3);
	}
	
}
